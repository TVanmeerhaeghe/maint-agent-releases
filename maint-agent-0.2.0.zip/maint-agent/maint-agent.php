<?php
/**
 * Plugin Name:       Maint Agent
 * Description:       Expose l'inventaire du site (versions, extensions, thèmes) à l'outil de maintenance. Lecture seule.
 * Version:           0.2.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Update URI:        https://github.com/TVanmeerhaeghe/maint-agent-releases
 */

declare(strict_types=1);

namespace MaintAgent;

if (!defined('ABSPATH')) {
    exit;
}

const VERSION = '0.2.0';

// Clé publique de publication : seules les versions signées par la clé privée
// correspondante peuvent remplacer ce plugin.
const RELEASE_PUBLIC_KEY = 'pgYhoMgPZfNDis5q70OrGCmi+A7h5M/8ULp92cvV1uc=';
const RELEASE_MANIFEST_URL = 'https://github.com/TVanmeerhaeghe/maint-agent-releases/releases/latest/download/latest.json';

require_once __DIR__ . '/src/Envelope.php';
require_once __DIR__ . '/src/Inventory.php';
require_once __DIR__ . '/src/Keys.php';
require_once __DIR__ . '/src/Release.php';
require_once __DIR__ . '/src/Signature.php';

// Le nom du filtre dérive de l'hôte de l'en-tête Update URI, qui écarte aussi
// les mises à jour de wordpress.org pour une extension homonyme.
add_filter('update_plugins_github.com', __NAMESPACE__ . '\\offer_update', 10, 3);
add_filter('upgrader_pre_download', __NAMESPACE__ . '\\download_update', PHP_INT_MAX, 4);

add_action('rest_api_init', static function (): void {
    register_rest_route('maint-agent/v1', '/inventory', [
        'methods' => 'GET',
        'callback' => __NAMESPACE__ . '\\handle_inventory',
        'permission_callback' => __NAMESPACE__ . '\\authorize',
    ]);
});

/**
 * Tout refus renvoie la même erreur générique de WordPress : l'appelant
 * ne doit pas pouvoir distinguer une clé absente d'une signature fausse.
 */
function authorize(\WP_REST_Request $request): bool
{
    $publicKey = signing_public_key();
    if ($publicKey === null || encryption_public_key() === null) {
        return false;
    }

    $query = $request->get_query_params();
    $timestamp = $query['ts'] ?? null;
    $nonce = $query['nonce'] ?? null;
    $signature = $request->get_header('x_maint_signature');
    $host = wp_parse_url(home_url(), PHP_URL_HOST);
    if (!is_string($timestamp) || !is_string($nonce) || !is_string($signature) || !is_string($host)) {
        return false;
    }

    $valid = Signature::isValid(
        $publicKey,
        $request->get_method(),
        $host,
        $request->get_route(),
        $timestamp,
        $nonce,
        $signature,
        time()
    );

    // Le nonce n'est consommé qu'après la signature : une requête non
    // authentifiée ne doit rien pouvoir écrire en base.
    return $valid && consume_nonce($nonce);
}

function signing_public_key(): ?string
{
    return configured_key('MAINT_AGENT_SIGNING_PUBLIC_KEY', SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES);
}

function encryption_public_key(): ?string
{
    return configured_key('MAINT_AGENT_ENCRYPTION_PUBLIC_KEY', SODIUM_CRYPTO_BOX_PUBLICKEYBYTES);
}

/**
 * @param positive-int $length
 */
function configured_key(string $constant, int $length): ?string
{
    if (!defined($constant)) {
        return null;
    }

    return Keys::decode(constant($constant), $length);
}

function consume_nonce(string $nonce): bool
{
    $key = 'maint_agent_nonce_' . hash('sha256', $nonce);
    if (get_transient($key) !== false) {
        return false;
    }

    set_transient($key, 1, Signature::NONCE_TTL);

    return true;
}

/**
 * @return \WP_REST_Response|\WP_Error
 */
function handle_inventory()
{
    $publicKey = encryption_public_key();
    if ($publicKey === null) {
        return generic_error();
    }

    try {
        $envelope = Envelope::seal(collect_inventory(), $publicKey);
    } catch (\Throwable $e) {
        return generic_error();
    }

    $response = new \WP_REST_Response($envelope);
    $response->header('Cache-Control', 'no-store');

    return $response;
}

function generic_error(): \WP_Error
{
    return new \WP_Error('maint_agent_error', 'Internal error.', ['status' => 500]);
}

/**
 * @return array<string, mixed>
 */
function collect_inventory(): array
{
    require_once ABSPATH . 'wp-admin/includes/plugin.php';

    $plugins = [];
    foreach (get_plugins() as $file => $data) {
        $plugins[] = [
            'file' => (string) $file,
            'version' => is_string($data['Version'] ?? null) ? $data['Version'] : '',
            'active' => is_plugin_active($file),
        ];
    }

    $activeThemes = [get_stylesheet(), get_template()];
    $themes = [];
    foreach (wp_get_themes() as $stylesheet => $theme) {
        $themes[] = [
            'stylesheet' => (string) $stylesheet,
            'version' => (string) $theme->get('Version'),
            'active' => in_array((string) $stylesheet, $activeThemes, true),
        ];
    }

    $coreVersion = core_version();

    return Inventory::build(
        VERSION,
        $coreVersion,
        Inventory::coreUpdateVersion(get_site_transient('update_core'), $coreVersion),
        PHP_VERSION,
        $plugins,
        Inventory::updateVersions(get_site_transient('update_plugins')),
        $themes,
        Inventory::updateVersions(get_site_transient('update_themes'))
    );
}

/**
 * @param mixed $update
 * @param mixed $pluginData
 * @param mixed $pluginFile
 *
 * @return mixed
 */
function offer_update($update, $pluginData, $pluginFile)
{
    if ($pluginFile !== plugin_basename(__FILE__)) {
        return $update;
    }

    $release = fetch_release();
    if ($release === null) {
        return $update;
    }

    return [
        'slug' => 'maint-agent',
        'version' => $release['version'],
        'package' => $release['package'],
        'requires_php' => $release['requires_php'],
        'url' => 'https://github.com/TVanmeerhaeghe/maint-agent-releases',
    ];
}

/**
 * Toute mise à jour de ce plugin passe par ici, quelle que soit l'origine du
 * paquet annoncé : WordPress n'installe que le zip dont l'empreinte figure
 * dans un manifeste signé, et rien si la vérification échoue.
 *
 * @param mixed $reply
 * @param mixed $package
 * @param mixed $upgrader
 * @param mixed $hookExtra
 *
 * @return mixed
 */
function download_update($reply, $package, $upgrader, $hookExtra)
{
    if (!is_array($hookExtra) || ($hookExtra['plugin'] ?? null) !== plugin_basename(__FILE__)) {
        return $reply;
    }

    $release = fetch_release();
    if (
        $release === null
        || !Release::isNewer($release['version'], VERSION)
        || !is_php_version_compatible($release['requires_php'])
    ) {
        return update_error();
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    $file = download_url($release['package'], 300);
    if (is_wp_error($file)) {
        return $file;
    }
    if (!Release::matchesFile($file, $release['sha256'])) {
        wp_delete_file($file);

        return update_error();
    }

    return $file;
}

function update_error(): \WP_Error
{
    return new \WP_Error('maint_agent_update_unverified', 'The Maint Agent update could not be verified.');
}

/**
 * @return array{version: string, requires_php: string, package: string, sha256: string}|null
 */
function fetch_release(): ?array
{
    $publicKey = Keys::decode(RELEASE_PUBLIC_KEY, SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES);
    if ($publicKey === null) {
        return null;
    }

    $response = wp_safe_remote_get(RELEASE_MANIFEST_URL, [
        'timeout' => 10,
        'limit_response_size' => Release::MAX_MANIFEST_SIZE,
    ]);
    if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
        return null;
    }

    return Release::parseManifest(wp_remote_retrieve_body($response), $publicKey);
}

/**
 * Relit version.php plutôt que la globale $wp_version, que des extensions
 * de sécurité modifient pour masquer la version réelle.
 */
function core_version(): string
{
    require ABSPATH . WPINC . '/version.php';

    /** @var string $wp_version */
    return $wp_version;
}
