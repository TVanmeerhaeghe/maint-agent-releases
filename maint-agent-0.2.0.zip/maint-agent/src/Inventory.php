<?php

declare(strict_types=1);

namespace MaintAgent;

if (!defined('ABSPATH')) {
    exit;
}

final class Inventory
{
    /**
     * @param list<array{file: string, version: string, active: bool}>       $plugins
     * @param array<string, string>                                          $pluginUpdates
     * @param list<array{stylesheet: string, version: string, active: bool}> $themes
     * @param array<string, string>                                          $themeUpdates
     *
     * @return array<string, mixed>
     */
    public static function build(
        string $agentVersion,
        string $wpVersion,
        ?string $wpUpdateVersion,
        string $phpVersion,
        array $plugins,
        array $pluginUpdates,
        array $themes,
        array $themeUpdates
    ): array {
        $pluginItems = [];
        foreach ($plugins as $plugin) {
            $pluginItems[] = [
                'slug' => self::pluginSlug($plugin['file']),
                'version' => $plugin['version'],
                'active' => $plugin['active'],
                'update_version' => $pluginUpdates[$plugin['file']] ?? null,
            ];
        }

        $themeItems = [];
        foreach ($themes as $theme) {
            $themeItems[] = [
                'slug' => $theme['stylesheet'],
                'version' => $theme['version'],
                'active' => $theme['active'],
                'update_version' => $themeUpdates[$theme['stylesheet']] ?? null,
            ];
        }

        return [
            'agent_version' => $agentVersion,
            'wp_version' => $wpVersion,
            'wp_update_version' => $wpUpdateVersion,
            'php_version' => $phpVersion,
            'plugins' => self::sortBySlug($pluginItems),
            'themes' => self::sortBySlug($themeItems),
        ];
    }

    public static function pluginSlug(string $file): string
    {
        $separator = strpos($file, '/');
        if ($separator === false) {
            return basename($file, '.php');
        }

        return substr($file, 0, $separator);
    }

    /**
     * Les transients update_plugins et update_themes n'ont pas la même forme :
     * objets pour les plugins, tableaux pour les thèmes.
     *
     * @param mixed $transient
     *
     * @return array<string, string>
     */
    public static function updateVersions($transient): array
    {
        if (!is_object($transient) || !isset($transient->response) || !is_array($transient->response)) {
            return [];
        }

        $versions = [];
        foreach ($transient->response as $key => $entry) {
            $entry = (array) $entry;
            if (isset($entry['new_version']) && is_string($entry['new_version']) && $entry['new_version'] !== '') {
                $versions[(string) $key] = $entry['new_version'];
            }
        }

        return $versions;
    }

    /**
     * Le transient update_core liste plusieurs offres (dont la réinstallation
     * de la version courante) : seule la plus haute mise à niveau compte.
     *
     * @param mixed $transient
     */
    public static function coreUpdateVersion($transient, string $currentVersion): ?string
    {
        if (!is_object($transient) || !isset($transient->updates) || !is_array($transient->updates)) {
            return null;
        }

        $best = null;
        foreach ($transient->updates as $offer) {
            $offer = (array) $offer;
            $version = $offer['version'] ?? null;
            if (($offer['response'] ?? null) !== 'upgrade' || !is_string($version) || $version === '') {
                continue;
            }
            if (version_compare($version, $best ?? $currentVersion, '>')) {
                $best = $version;
            }
        }

        return $best;
    }

    /**
     * @param list<array{slug: string, version: string, active: bool, update_version: ?string}> $items
     *
     * @return list<array{slug: string, version: string, active: bool, update_version: ?string}>
     */
    private static function sortBySlug(array $items): array
    {
        usort($items, static function (array $a, array $b): int {
            return strcmp($a['slug'], $b['slug']);
        });

        return $items;
    }
}
