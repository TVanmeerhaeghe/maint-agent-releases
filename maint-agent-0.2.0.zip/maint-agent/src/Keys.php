<?php

declare(strict_types=1);

namespace MaintAgent;

if (!defined('ABSPATH')) {
    exit;
}

final class Keys
{
    /**
     * @param mixed        $encoded
     * @param positive-int $length
     *
     * @return non-empty-string|null
     */
    public static function decode($encoded, int $length): ?string
    {
        if (!is_string($encoded)) {
            return null;
        }

        $decoded = base64_decode($encoded, true);
        if ($decoded === false || strlen($decoded) !== $length) {
            return null;
        }

        return $decoded;
    }
}
