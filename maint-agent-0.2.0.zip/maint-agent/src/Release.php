<?php

declare(strict_types=1);

namespace MaintAgent;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Le serveur qui publie les versions n'est pas de confiance : seul le
 * manifeste signé avec la clé de publication fait foi, et il désigne le zip
 * par son empreinte.
 */
final class Release
{
    public const MAX_MANIFEST_SIZE = 65536;

    private const VERSION_PATTERN = '/\A[0-9][0-9A-Za-z.-]*\z/';

    public static function message(string $version, string $requiresPhp, string $sha256): string
    {
        return implode('|', ['maint-agent', $version, $requiresPhp, $sha256]);
    }

    /**
     * @return array{version: string, requires_php: string, package: string, sha256: string}|null
     */
    public static function parseManifest(string $body, string $publicKey): ?array
    {
        if (strlen($publicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES || strlen($body) > self::MAX_MANIFEST_SIZE) {
            return null;
        }

        $data = json_decode($body, true);
        if (!is_array($data)) {
            return null;
        }
        $version = $data['version'] ?? null;
        $requiresPhp = $data['requires_php'] ?? null;
        $package = $data['package'] ?? null;
        $sha256 = $data['sha256'] ?? null;
        if (!is_string($version) || !is_string($requiresPhp) || !is_string($package) || !is_string($sha256)) {
            return null;
        }
        if (
            preg_match(self::VERSION_PATTERN, $version) !== 1
            || preg_match(self::VERSION_PATTERN, $requiresPhp) !== 1
            || preg_match('/\A[0-9a-f]{64}\z/', $sha256) !== 1
            || strpos($package, 'https://') !== 0
        ) {
            return null;
        }

        $signature = Keys::decode($data['signature'] ?? null, SODIUM_CRYPTO_SIGN_BYTES);
        if ($signature === null) {
            return null;
        }
        if (!sodium_crypto_sign_verify_detached($signature, self::message($version, $requiresPhp, $sha256), $publicKey)) {
            return null;
        }

        return [
            'version' => $version,
            'requires_php' => $requiresPhp,
            'package' => $package,
            'sha256' => $sha256,
        ];
    }

    /**
     * Interdit aussi la réinstallation et le retour à une version plus
     * ancienne, même signée : elle pourrait contenir une faille corrigée depuis.
     */
    public static function isNewer(string $candidate, string $installed): bool
    {
        return version_compare($candidate, $installed, '>');
    }

    public static function matchesFile(string $path, string $sha256): bool
    {
        $actual = hash_file('sha256', $path);

        return $actual !== false && hash_equals($sha256, $actual);
    }
}
