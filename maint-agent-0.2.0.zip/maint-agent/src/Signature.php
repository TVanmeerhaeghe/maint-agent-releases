<?php

declare(strict_types=1);

namespace MaintAgent;

if (!defined('ABSPATH')) {
    exit;
}

final class Signature
{
    public const MAX_CLOCK_SKEW = 300;

    // Plus long que la fenêtre d'horodatage : un nonce ne peut pas être
    // oublié alors que la requête qui le porte est encore acceptable.
    public const NONCE_TTL = 600;

    public static function message(string $method, string $host, string $route, string $timestamp, string $nonce): string
    {
        return implode('|', [strtoupper($method), strtolower($host), $route, $timestamp, $nonce]);
    }

    public static function isValid(
        string $publicKey,
        string $method,
        string $host,
        string $route,
        string $timestamp,
        string $nonce,
        string $encodedSignature,
        int $now
    ): bool {
        if (strlen($publicKey) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {
            return false;
        }
        if (!self::isFreshTimestamp($timestamp, $now) || !self::isWellFormedNonce($nonce)) {
            return false;
        }

        $signature = Keys::decode($encodedSignature, SODIUM_CRYPTO_SIGN_BYTES);
        if ($signature === null) {
            return false;
        }

        return sodium_crypto_sign_verify_detached(
            $signature,
            self::message($method, $host, $route, $timestamp, $nonce),
            $publicKey
        );
    }

    public static function isWellFormedNonce(string $nonce): bool
    {
        return preg_match('/\A[A-Za-z0-9_-]{22,64}\z/', $nonce) === 1;
    }

    private static function isFreshTimestamp(string $timestamp, int $now): bool
    {
        if (preg_match('/\A[1-9][0-9]{0,11}\z/', $timestamp) !== 1) {
            return false;
        }

        return abs($now - (int) $timestamp) <= self::MAX_CLOCK_SKEW;
    }
}
