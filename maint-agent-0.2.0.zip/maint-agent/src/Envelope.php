<?php

declare(strict_types=1);

namespace MaintAgent;

if (!defined('ABSPATH')) {
    exit;
}

final class Envelope
{
    public const VERSION = 1;

    /**
     * Boîte scellée : chiffrée avec la seule clé publique du backend, donc
     * illisible pour le site lui-même une fois produite.
     *
     * @param array<string, mixed> $payload
     *
     * @return array{v: int, sealed: string}
     *
     * @throws \JsonException
     * @throws \SodiumException
     */
    public static function seal(array $payload, string $publicKey): array
    {
        $json = json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);

        return [
            'v' => self::VERSION,
            'sealed' => base64_encode(sodium_crypto_box_seal($json, $publicKey)),
        ];
    }
}
